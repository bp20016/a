package Othello_CUI;

import java.util.Scanner;

public class Main {
	public static void main(String[] args){

	    Board.initialize();
	    Board.showBoard();

	    Scanner s = new Scanner(System.in);

	    while(Board.game){

	      System.out.print("駒を置く行を入力してください:");
	      int y = s.nextInt() - 1;

	      System.out.print("駒を置く列を入力してください:");
	      int x = s.nextInt() - 1;
	      
	      if(x>7 || x<0 || y>7 || y<0) {
	    	  System.out.println("そこには置けません。ルールを確認してください");
	    	  continue;
	    	  
	      }
	      
	      if(!(Board.board[y][x].equals(Board.EMPTY))) {
	    	  System.out.println("そこには置けません。ルールを確認してください");
	    	  continue;
	    	  
	      }
	      
	      if(Board.board[y][x].equals(Board.EMPTY)) {
				
				Board.turnStone(x, y);				

			    if(Board.revCheck) {
			    	System.out.println("そこには置けません。ルールを確認してください");
			    	continue;
			    }
			    
			    Board.board[y][x] = Board.stone;
				
				String nextRevStone = Board.stone;
				Board.stone = Board.revStone;
				Board.revStone = nextRevStone;
				
				Board.showBoard();
				
			}
	      
	    }

	    s.close();
	  }
}
